# from .import views
from django.urls import path
from .views import(
    list_all_shipment,
    shipment_details,
    GetList,
    AddShipmentAPIView,
    )

urlpatterns = [
    path('ListAllShipment/', list_all_shipment, name='list_all_shipment'),     # List of All Shipments From LocalDB and Company API's
    path('ShipmentDetails/', shipment_details, name='shipment_details'), # Detail of Particular Shipments via shipment_id
    path('GetList/', GetList, name='GetList'), # This is return user added Shop(shipments)
    path('addShipments/', AddShipmentAPIView, name='AddShipmentAPIView'),  # Via this we can Add more Shop in DB
]



